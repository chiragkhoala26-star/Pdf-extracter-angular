# PDF Transaction Processor — Angular + TypeScript

This is a standalone Angular + TypeScript rebuild of the PDF Transaction Processor MVP
(originally built in React/TanStack Start on Lovable). It does the same things:

1. Upload one or more transaction PDFs (drag & drop or file picker).
2. AI extracts 8 fields: transaction_id, transaction_name, loan_amount, loan_type,
   business_unit, opportunity_id, trade_fee, cash_balance.
3. An Excel (.xlsx) file is generated per PDF, downloadable from the UI.
4. The extracted data + Excel are POSTed to the Global Application API.
   A built-in dummy/mock Global API is included so you can verify the call end to end.

## Project layout

```
angular-pdf-app/
├── client/   # Angular 18 frontend (standalone components, TypeScript)
└── server/   # Node + Express + TypeScript backend (REST API)
```

Angular is a frontend framework, so the PDF processing (AI extraction, Excel generation,
Global API call) lives in the `server/` folder as REST endpoints — same architecture as
the original app.

## Prerequisites

- Node.js 20 or newer
- npm (comes with Node)

## 1. Start the backend (port 3000)

```bash
cd server
npm install
cp .env.example .env   # then edit .env — see "Configuration" below
npm run dev
```

Endpoints:

- `POST /api/process-pdf` — multipart form, field name `file` (a PDF). Validates the PDF,
  extracts fields via AI, builds the Excel, posts to the Global API, returns everything as JSON.
- `POST /api/public/global-api-mock` — dummy Global Application API. Receives
  `{ transaction, excel }` and returns a booking reference + Excel filename/size so you can
  confirm the Excel was received.

## 2. Start the frontend (port 4200)

In a second terminal:

```bash
cd client
npm install
npm start
```

Then open http://localhost:4200. API calls to `/api/*` are proxied to the backend on
port 3000 automatically (see `client/proxy.conf.json`).

## Configuration (server/.env)

| Variable        | Purpose                                                              |
|-----------------|----------------------------------------------------------------------|
| `AI_PROVIDER`   | `lovable` (default, OpenAI-compatible) or `gemini` (Google direct).  |
| `AI_API_URL`    | Chat-completions URL for the `lovable` provider. Defaults to the Lovable AI Gateway. |
| `AI_API_KEY`    | API key for the AI provider.                                         |
| `AI_MODEL`      | Model name. Default `google/gemini-2.5-flash` (lovable) or `gemini-2.5-flash` (gemini). |
| `GLOBAL_API_URL`| Real Global Application API URL. If unset, the built-in mock is used.|
| `GLOBAL_API_KEY`| Bearer token sent to the real Global API (optional).                  |
| `PORT`          | Backend port. Default `3000`.                                        |

### About the AI key

Inside Lovable, extraction used the managed `LOVABLE_API_KEY` automatically. That key only
works inside Lovable, so for local runs pick one of:

- **Google Gemini (easiest free option):** get an API key at https://aistudio.google.com/apikey
  and set in `.env`:
  ```
  AI_PROVIDER=gemini
  AI_API_KEY=your-gemini-key
  ```
- **Any OpenAI-compatible endpoint that accepts PDF file input:** set `AI_PROVIDER=lovable`,
  `AI_API_URL`, `AI_API_KEY`, and `AI_MODEL` accordingly.

## How it maps to the original (React) version

| Original (React / TanStack Start)        | This project (Angular)                          |
|------------------------------------------|-------------------------------------------------|
| `src/routes/index.tsx` (upload UI)       | `client/src/app/app.component.ts` + `.html`     |
| `src/routes/api/process-pdf.ts`          | `server/src/index.ts` → `POST /api/process-pdf` |
| `src/lib/pipeline/extract.server.ts`     | `server/src/extract.ts`                         |
| `src/lib/pipeline/excel.server.ts`       | `server/src/excel.ts`                           |
| `src/lib/pipeline/global-api.server.ts`  | `server/src/globalApi.ts`                       |
| `src/routes/api/public/global-api-mock.ts` | `server/src/index.ts` → `POST /api/public/global-api-mock` |

## Recommended IDE

VS Code with the **Angular Language Service** extension (by Angular) — it gives you
template autocomplete, type checking inside templates, and go-to-definition.
