// AI extraction of transaction fields from a PDF.
// Two providers are supported, selected with AI_PROVIDER in .env:
//   - "lovable" (default): any OpenAI-compatible chat-completions endpoint
//     that accepts PDF file input (e.g. the Lovable AI Gateway).
//   - "gemini": Google Gemini API directly (works with a free AI Studio key).

export const FIELDS = [
  "transaction_id",
  "transaction_name",
  "loan_amount",
  "loan_type",
  "business_unit",
  "opportunity_id",
  "trade_fee",
  "cash_balance",
] as const;

export type Transaction = Record<(typeof FIELDS)[number], string>;

const PROMPT = `Extract these fields from the transaction PDF: ${FIELDS.join(", ")}. ` +
  `Use empty string if a field is not found. loan_amount, trade_fee and cash_balance as plain number strings.`;

const responseSchema = {
  type: "object",
  properties: Object.fromEntries(FIELDS.map((f) => [f, { type: "string" }])),
  required: [...FIELDS],
};

export async function extractTransaction(pdf: Buffer): Promise<Partial<Transaction>> {
  const provider = process.env["AI_PROVIDER"] || "lovable";
  return provider === "gemini" ? extractWithGemini(pdf) : extractWithOpenAiCompatible(pdf);
}

async function extractWithOpenAiCompatible(pdf: Buffer): Promise<Partial<Transaction>> {
  const key = process.env["AI_API_KEY"] || process.env["LOVABLE_API_KEY"];
  if (!key) throw new Error("Extraction service is not configured (set AI_API_KEY in .env)");
  const url = process.env["AI_API_URL"] || "https://ai.gateway.lovable.dev/v1/chat/completions";
  const model = process.env["AI_MODEL"] || "google/gemini-2.5-flash";
  const b64 = pdf.toString("base64");

  const res = await fetch(url, {
    method: "POST",
    headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      model,
      messages: [
        {
          role: "user",
          content: [
            { type: "text", text: PROMPT },
            { type: "file", file: { filename: "doc.pdf", file_data: `data:application/pdf;base64,${b64}` } },
          ],
        },
      ],
      tools: [
        {
          type: "function",
          function: { name: "save_transaction", parameters: responseSchema },
        },
      ],
      tool_choice: { type: "function", function: { name: "save_transaction" } },
    }),
  });
  if (res.status === 429) throw new Error("Extraction rate limit reached, try again shortly");
  if (res.status === 402) throw new Error("AI credits exhausted");
  if (!res.ok) throw new Error(`Extraction failed (${res.status})`);
  const json = await res.json();
  const args = json.choices?.[0]?.message?.tool_calls?.[0]?.function?.arguments;
  if (!args) throw new Error("Extraction returned no data");
  return JSON.parse(args);
}

async function extractWithGemini(pdf: Buffer): Promise<Partial<Transaction>> {
  const key = process.env["AI_API_KEY"];
  if (!key) throw new Error("Extraction service is not configured (set AI_API_KEY in .env)");
  const model = process.env["AI_MODEL"] || "gemini-2.5-flash";
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${key}`;

  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      contents: [
        {
          role: "user",
          parts: [
            { text: PROMPT },
            { inline_data: { mime_type: "application/pdf", data: pdf.toString("base64") } },
          ],
        },
      ],
      generationConfig: {
        response_mime_type: "application/json",
        response_schema: responseSchema,
      },
    }),
  });
  if (res.status === 429) throw new Error("Extraction rate limit reached, try again shortly");
  if (!res.ok) throw new Error(`Extraction failed (${res.status})`);
  const json = await res.json();
  const text = json.candidates?.[0]?.content?.parts?.[0]?.text;
  if (!text) throw new Error("Extraction returned no data");
  return JSON.parse(text);
}
