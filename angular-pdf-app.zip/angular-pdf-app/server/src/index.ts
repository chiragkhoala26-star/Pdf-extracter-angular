import "dotenv/config";
import express from "express";
import multer from "multer";
import { extractTransaction, FIELDS, type Transaction } from "./extract";
import { buildExcelBase64 } from "./excel";
import { sendToGlobalApi } from "./globalApi";

const app = express();
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 15 * 1024 * 1024 },
});

const err = (res: express.Response, stage: string, message: string, status = 400, extra: object = {}) =>
  res.status(status).json({ status: "error", stage, message, ...extra });

// Main pipeline: PDF -> AI extraction -> Excel -> Global API
app.post("/api/process-pdf", upload.single("file"), async (req, res) => {
  const file = req.file;
  if (!file) return err(res, "upload", "Expected multipart form data with a 'file' field");
  if (file.buffer.subarray(0, 5).toString("utf-8") !== "%PDF-") {
    return err(res, "validation", "File is not a valid PDF");
  }

  let raw: Partial<Transaction>;
  try {
    raw = await extractTransaction(file.buffer);
  } catch (e) {
    return err(res, "extraction", e instanceof Error ? e.message : "Extraction failed", 502);
  }

  const data = Object.fromEntries(FIELDS.map((f) => [f, String(raw[f] ?? "").trim()])) as Transaction;
  const missing = FIELDS.filter((f) => !data[f]);
  if (missing.length) {
    return err(res, "validation", `Missing fields: ${missing.join(", ")}`, 422, { data, missing });
  }

  let excel: string;
  try {
    excel = buildExcelBase64(data);
  } catch {
    return err(res, "excel", "Excel generation failed", 500, { data });
  }

  const excelFile = { filename: `transaction_${data.transaction_id}.xlsx`, base64: excel };
  const origin = `${req.protocol}://${req.get("host")}`;
  const globalApi = await sendToGlobalApi(data, excelFile, origin);

  return res.json({
    status: globalApi.status === "success" ? "success" : "partial",
    data,
    globalApi,
    excel: excelFile,
  });
});

// Dummy Global Application API: accepts a transaction + Excel and returns a booking reference.
app.post("/api/public/global-api-mock", express.json(), (req, res) => {
  const body = req.body as {
    transaction?: Record<string, string>;
    excel?: { filename?: string; base64?: string };
  };
  const b64 = body.excel?.base64 ?? "";
  if (!body.transaction || !b64) {
    return res.status(400).json({ ok: false, error: "transaction and excel are required" });
  }
  const excelBytes = Math.floor((b64.length * 3) / 4);
  return res.json({
    ok: true,
    bookingReference: `GA-${Date.now().toString(36).toUpperCase()}`,
    receivedAt: new Date().toISOString(),
    transactionId: body.transaction["transaction_id"],
    excelReceived: { filename: body.excel?.filename, sizeBytes: excelBytes },
    message: "Transaction booked (dummy Global API)",
  });
});

const port = Number(process.env["PORT"] || 3000);
app.listen(port, () => {
  console.log(`PDF transaction server listening on http://localhost:${port}`);
});
