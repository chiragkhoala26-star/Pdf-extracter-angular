import { Component } from "@angular/core";
import { CommonModule } from "@angular/common";
import { firstValueFrom } from "rxjs";
import { PdfProcessorService } from "./pdf-processor.service";
import { Item, ProcessResult } from "./models";

@Component({
  selector: "app-root",
  standalone: true,
  imports: [CommonModule],
  templateUrl: "./app.component.html",
})
export class AppComponent {
  items: Item[] = [];

  constructor(private api: PdfProcessorService) {}

  get busy(): boolean {
    return this.items.some((i) => i.busy);
  }

  get pendingCount(): number {
    return this.items.filter((i) => !i.res).length;
  }

  add(list: FileList | null): void {
    if (!list) return;
    const added: Item[] = Array.from(list).map((file) => ({ file, busy: false, res: null }));
    this.items = [...this.items, ...added];
  }

  onFileChange(event: Event): void {
    const input = event.target as HTMLInputElement;
    this.add(input.files);
    input.value = "";
  }

  onDragOver(event: DragEvent): void {
    event.preventDefault();
  }

  onDrop(event: DragEvent): void {
    event.preventDefault();
    this.add(event.dataTransfer?.files ?? null);
  }

  clear(): void {
    this.items = [];
  }

  async processAll(): Promise<void> {
    const targets = this.items
      .map((it, idx) => ({ it, idx }))
      .filter(({ it }) => !it.res);
    this.items = this.items.map((it) => (it.res ? it : { ...it, busy: true }));

    await Promise.all(
      targets.map(async ({ it, idx }) => {
        let res: ProcessResult;
        try {
          res = await firstValueFrom(this.api.process(it.file));
        } catch (e: unknown) {
          const httpErr = e as { error?: ProcessResult };
          res = httpErr?.error?.status
            ? httpErr.error
            : { status: "error", message: "Network error" };
        }
        this.items = this.items.map((p, i) => (i === idx ? { ...p, busy: false, res } : p));
      }),
    );
  }

  download(excel: { filename: string; base64: string }): void {
    const bytes = Uint8Array.from(atob(excel.base64), (c) => c.charCodeAt(0));
    const url = URL.createObjectURL(
      new Blob([bytes], {
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      }),
    );
    const a = document.createElement("a");
    a.href = url;
    a.download = excel.filename;
    a.click();
    URL.revokeObjectURL(url);
  }

  trackByIdx(index: number): number {
    return index;
  }
}
