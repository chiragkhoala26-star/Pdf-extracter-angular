export interface GlobalApiResult {
  status: string;
  httpStatus?: number;
  error?: string;
  response?: unknown;
}

export interface ProcessResult {
  status: string;
  message?: string;
  stage?: string;
  data?: Record<string, string>;
  missing?: string[];
  globalApi?: GlobalApiResult;
  excel?: { filename: string; base64: string };
}

export interface Item {
  file: File;
  busy: boolean;
  res: ProcessResult | null;
}
