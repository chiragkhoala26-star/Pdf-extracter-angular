import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs";
import { ProcessResult } from "./models";

@Injectable({ providedIn: "root" })
export class PdfProcessorService {
  constructor(private http: HttpClient) {}

  process(file: File): Observable<ProcessResult> {
    const fd = new FormData();
    fd.append("file", file);
    return this.http.post<ProcessResult>("/api/process-pdf", fd);
  }
}
